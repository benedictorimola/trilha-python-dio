# image_processing

Descrition.<br>
Pacote process_image usado para:<br>
Processing:
- criar uma ficura com marca d´água

## Instalation
Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install process_image
```